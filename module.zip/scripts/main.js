/**
 * 🎭 Stage Speaker Module
 * 토큰 없이 액터를 채팅 화자로 선택하는 모듈
 */

const MODULE_ID = "stage-speaker";

class StageHUD extends Application {
    constructor() {
        super();
        this.actors = []; // 무대에 올라온 액터 ID 목록
        this.activeActorId = null; // 현재 말하는 액터
    }

    static get defaultOptions() {
        return foundry.utils.mergeObject(super.defaultOptions, {
            id: "stage-hud",
            template: null, // 템플릿 파일 없이 직접 렌더링 (인라인 스타일 준수)
            popOut: false,
            minimizable: false,
        });
    }

    // 초기화 및 데이터 로드
    async _render(force, options) {
        // 기존 렌더링이 있으면 제거하지 않고 내용만 갱신하거나, 최초 1회만 생성
        if (document.getElementById("stage-hud")) {
            this.updateContent();
            return;
        }
        await super._render(force, options);
        this.updateContent();
    }

    // HTML 구조 생성 (인라인 스타일)
    getData() {
        return {}; // 템플릿을 안 쓰므로 빈 객체 반환
    }

    _injectHTML(html) {
        $('body').append(html);
        this._element = html;
    }

    // 실제 화면 그리기
    updateContent() {
        const container = document.getElementById("stage-hud");
        if (!container) return;

        let htmlContent = "";
        
        this.actors.forEach(actorId => {
            const actor = game.actors.get(actorId);
            if (!actor) return;

            const isActive = (actorId === this.activeActorId);
            const borderStyle = isActive ? "border: 3px solid #ffd700; box-shadow: 0 0 15px #ffd700;" : "border: 2px solid #333; filter: grayscale(0.5);";
            const scaleStyle = isActive ? "transform: scale(1.1);" : "transform: scale(1.0);";

            htmlContent += `
            <div class="stage-actor" data-id="${actorId}" style="
                width: 60px;
                height: 60px;
                margin: 0 5px;
                border-radius: 50%;
                background-image: url('${actor.img}');
                background-size: cover;
                background-position: center;
                cursor: pointer;
                transition: all 0.2s ease;
                position: relative;
                ${borderStyle}
                ${scaleStyle}
            " title="${actor.name}">
                ${isActive ? '<div style="position:absolute; bottom:-5px; left:50%; transform:translateX(-50%); font-size:16px;">🎤</div>' : ''}
            </div>`;
        });

        // 빈 슬롯 (드래그 앤 드롭 유도)
        if (this.actors.length === 0) {
            htmlContent = `<div style="color:#aaa; font-size:12px; font-weight:bold; padding:10px;">액터를 여기에 드래그하세요</div>`;
        }

        container.innerHTML = htmlContent;
        this.activateListeners($(container));
    }

    activateListeners(html) {
        // 클릭: 활성화
        html.find(".stage-actor").click((ev) => {
            const id = ev.currentTarget.dataset.id;
            if (this.activeActorId === id) {
                this.activeActorId = null; // 이미 선택된거 누르면 해제
                ui.notifications.info("🎤 화자 선택 해제");
            } else {
                this.activeActorId = id;
                const actor = game.actors.get(id);
                ui.notifications.info(`🎤 화자 선택: ${actor.name}`);
            }
            this.updateContent();
        });

        // 우클릭: 제거
        html.find(".stage-actor").contextmenu((ev) => {
            const id = ev.currentTarget.dataset.id;
            this.actors = this.actors.filter(a => a !== id);
            if (this.activeActorId === id) this.activeActorId = null;
            this.updateContent();
        });
    }
}

// 전역 인스턴스
let stageHUD;

Hooks.once('ready', () => {
    // 1. HUD 컨테이너 생성 (인라인 스타일)
    const hudDiv = document.createElement("div");
    hudDiv.id = "stage-hud";
    Object.assign(hudDiv.style, {
        position: "fixed",
        bottom: "10px",
        left: "250px", // 채팅창 옆, 매크로 바 위
        width: "auto",
        height: "80px",
        display: "flex",
        alignItems: "center",
        justifyContent: "flex-start",
        padding: "5px 15px",
        backgroundColor: "rgba(0, 0, 0, 0.7)",
        border: "1px solid #444",
        borderRadius: "40px",
        zIndex: "50",
        backdropFilter: "blur(5px)",
        pointerEvents: "auto"
    });
    document.body.appendChild(hudDiv);

    // 2. 앱 실행
    stageHUD = new StageHUD();
    stageHUD.render(true);

    // 3. 드래그 앤 드롭 처리 (액터를 HUD에 떨어뜨렸을 때)
    // Foundry의 DragDrop 동작을 가로채거나 HTML5 이벤트를 사용
    hudDiv.addEventListener("dragover", ev => ev.preventDefault());
    hudDiv.addEventListener("drop", async ev => {
        ev.preventDefault();
        try {
            const data = JSON.parse(ev.dataTransfer.getData("text/plain"));
            if (data.type === "Actor") {
                const actor = fromUuidSync(data.uuid);
                if (actor && !stageHUD.actors.includes(actor.id)) {
                    stageHUD.actors.push(actor.id);
                    stageHUD.updateContent();
                }
            }
        } catch (err) {
            console.error(err);
        }
    });
});

// 4. [핵심] 채팅 메시지 생성 가로채기 (preCreateChatMessage)
Hooks.on('preCreateChatMessage', (message, data, options, userId) => {
    // 내가 보낸 메시지가 아니면 패스
    if (userId !== game.user.id) return;
    
    // 활성화된 무대 액터가 없으면 패스 (기본 동작)
    if (!stageHUD || !stageHUD.activeActorId) return;

    // 명령어(/roll 등)나 OOC일 때는 적용 안 할 수도 있음 (선택 사항)
    // 여기서는 무조건 적용합니다.

    const actor = game.actors.get(stageHUD.activeActorId);
    if (!actor) return;

    // 메시지의 화자(Speaker) 정보를 덮어씌움
    // 토큰이 없어도 Actor 정보를 직접 주입하여 포트레잇이 나오게 함
    message.updateSource({
        speaker: {
            actor: actor.id,
            alias: actor.name,
            scene: null, // 씬과 토큰 정보를 지워야 Actor 자체 이미지를 씀
            token: null
        }
    });
    
    // 만약 채팅창 이미지가 토큰 이미지로 설정되어 있다면 Actor 이미지로 강제할 수도 있음
    // Foundry 기본 설정은 Actor 이미지를 우선하지만, 
    // Chat Portrait 같은 모듈을 쓴다면 그 설정에 따름
});